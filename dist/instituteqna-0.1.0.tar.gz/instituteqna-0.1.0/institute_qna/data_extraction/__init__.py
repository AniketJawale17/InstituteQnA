from .webscrapper import WebBasedLoader

__all__ = ["WebBasedLoader"]