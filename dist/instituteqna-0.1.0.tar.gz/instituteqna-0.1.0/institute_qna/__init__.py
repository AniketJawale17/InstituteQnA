"""InstituteQnA package."""

__version__ = "0.1.0"

from .data_extraction import WebBasedLoader

__all__ = ["WebBasedLoader"]
